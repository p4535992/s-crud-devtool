SHJS Linenumbers
================

Adding linenumbers to SHJS syntaxt highlighter

Usage
-----

just grab `src/sh_main.js` and make sure to have the right css classes styled, look at `src/sh_style.css`

You can also check out the example `example/example.html`

Licens
------

Distributed under the GNU General Public License version 3

[http://shjs.sourceforge.net/doc/gplv3.html](http://shjs.sourceforge.net/doc/gplv3.html)