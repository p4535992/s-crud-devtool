(function(angular) {
    'use strict';
    angular.module('fontAwesomeAnimationDemoApp', ['ui.bootstrap']);
})(angular);
