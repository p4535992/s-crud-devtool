package com.db.$WEBAPP ;
import  java.lang.* ;
import  java.io.* ;
import  java.sql.* ;
import  javax.naming.* ;
import  javax.sql.* ;
import  com.webapp.utils.* ;	
/*
 --- PORTABLE CODE ---
The code is not customized for any particular driver.
It is generic type of code expected to be portable across diverse drivers.
The detected driver is:   MySQL-AB JDBC Driver driver.
The JDBC driver version is: mysql-connector-java-5.1.12 ( Revision: ${bzr.revision-id} )
Autonumber column is: LogID
*/


public class DebuglogBean
{
	
/* JNDI data source name of database */
	public String _datasource = "jdbc/$WEBAPP" ;
/* Table name in SQL databse */
	public String _tablename = "debuglog"; 
/* Special public variable to hold last autonumber value */
	public int _autonumber = 0 ;
	
/* Variable to hold last error */
  public String lasterror=null;	
	
/* Variables corrosponding to table fields - field count: 4 */

/* Variable related to generating Portable SQL syntax */
   private com.webapp.utils.PortableSQL psql = null;
	       
 	public int LogID ; 
	public java.sql.Timestamp LogTime ; 
	public String Context ; 
	public String LogText ; 


/* Method to set JNDI Datasource name */

public void setDatasource(String jndi_dsn )
{
   _datasource = jndi_dsn ;
}

public void setSQLEngine(short eng )
{
     // Override engine detection process by creating 
	   // portable sql object with specified engine
     psql = new com.webapp.utils.PortableSQL(eng) ;	 
}

public String getEngineName()
{
   if(psql != null) return psql.getEngineName();
	 else return " Portable SQL Object is NULL " ;
}
	
/* Method to get connection */

private java.sql.Connection Connect()
throws java.sql.SQLException 
{
    java.sql.Connection conx=null;
    try
    {
         javax.naming.Context env = (javax.naming.Context) new InitialContext().lookup("java:comp/env");
         javax.sql.DataSource source = (javax.sql.DataSource) env.lookup(_datasource);
         conx= source.getConnection();
    }
    catch(javax.naming.NamingException ex)
    {
         lasterror=ex.toString();
         conx=null;
    }
    if( psql == null && conx!=null ) psql = new com.webapp.utils.PortableSQL(conx); 
    return conx ;
}


/* Method to close connecion */

private void Disconnect(java.sql.Connection cnx)
throws java.sql.SQLException 
{
 if(cnx==null) return ;
 cnx.close();
}

/* Copy Fields to other object of same kind */

public void copyTo(com.db.$WEBAPP.DebuglogBean other )
{
   other.LogID = this.LogID ;
   other.LogTime = this.LogTime ;
   other.Context = this.Context ;
   other.LogText = this.LogText ;
	
}

/* Copy Fields from other objects of same kind */

public void copyFrom(com.db.$WEBAPP.DebuglogBean other )
{
   this.LogID = other.LogID ;
   this.LogTime = other.LogTime ;
   this.Context = other.Context ;
   this.LogText = other.LogText ;
	
}

/* Move data from class variable data to statement fields fields */

public void storeData(java.sql.PreparedStatement stmt )
throws java.sql.SQLException 
{
stmt.setTimestamp( 1 , LogTime ) ; 
stmt.setString( 2 , Context ) ; 
stmt.setString( 3 , LogText ) ; 
	
} // end method storeData()
	 
/* Move data from fields to class variables */

public void loadData(java.sql.ResultSet rslt)
throws java.sql.SQLException
{
LogID = rslt.getInt("LogID"); 
LogTime = rslt.getTimestamp("LogTime"); 
Context = rslt.getString("Context"); 
LogText = rslt.getString("LogText"); 
	
}// end method loadData();
	 
/* Add new record from class variable */
public boolean addRecord()
throws java.sql.SQLException 
{
boolean  bAdded = false  ;	
 java.sql.Connection conn = Connect();
 if(conn==null) return false ;
 try{
    String query_add = psql.SQL(" INSERT INTO `debuglog` ( `LogTime`, `Context`, `LogText` ) VALUES ( ?, ?, ?  ) " );
    java.sql.PreparedStatement stmt_add = conn.prepareStatement(query_add, Statement.RETURN_GENERATED_KEYS);
    // move data from bean variables to prepared statement
    storeData(stmt_add);
    if( stmt_add.executeUpdate() == 1) bAdded = true ;
		
    try
		{
		  // Call getGeneratedKeys() for AUTOINCREMENT values
			// Take chance may not work with all drivers
			
		   java.sql.ResultSet rs_auto = stmt_add.getGeneratedKeys();
       if (rs_auto.next()) _autonumber = rs_auto.getInt(1);
       else _autonumber=0;
		   rs_auto.close();
	 		
		}
		catch(java.lang.Exception ex)
		{ 
		   // Default to 0 if getGeneratedKeys throws exeception for some reason
		   _autonumber=0;
		}
		
		stmt_add.close();
    }
 finally
    {
      Disconnect(conn);
    }
		
     /* 
       If the JDBC driver has detected auto_increment field properly
       than move auto generated key value to that field variable.
     */
     if( _autonumber > 0 ) LogID = _autonumber ;
	  
  return bAdded ;	
} // end method addRecord()

	
/* Create and prepare connection for multiple record inserts	 */

private  java.sql.Connection _conn_insert = null;
private  java.sql.PreparedStatement _stmt_insert=null;

public boolean beginInsert()
 throws java.sql.SQLException 
{
  boolean bReady = false ;
  _conn_insert = null;
  _stmt_insert=null;
   _conn_insert = Connect();
  if( _conn_insert==null )return false;
  String query_insert = psql.SQL(" INSERT INTO `debuglog` ( `LogTime`, `Context`, `LogText` ) VALUES ( ?, ?, ?  ) ");
  _stmt_insert = _conn_insert.prepareStatement(query_insert, Statement.RETURN_GENERATED_KEYS);
  if( _stmt_insert != null ) bReady = true ;
  return bReady ;
} // end method beginInsert()

/* Insert record from fields */

public boolean continueInsert()
 throws java.sql.SQLException 
{
  boolean bInsDone=false ;
  if ( _conn_insert == null ||  _stmt_insert == null ) return false ;
  storeData(_stmt_insert);
  if( _stmt_insert.executeUpdate() == 1) bInsDone = true ;
	 
   java.sql.ResultSet rs_auto_ins = _stmt_insert.getGeneratedKeys();
   if (rs_auto_ins.next() ) _autonumber = rs_auto_ins.getInt(1);
   else _autonumber=0;
   rs_auto_ins.close();
	 
		
     /* 
       If the JDBC driver has detected auto_increment field properly
       than move auto generated key value to that field variable.
     */
     if( _autonumber > 0 ) LogID = _autonumber ;
	  
  return bInsDone ;
} // end method continueInsert()

/* Close connection for  multiple inserts */
public void endInsert()
 throws java.sql.SQLException
{
  if(_stmt_insert!=null)_stmt_insert.close();
  Disconnect(_conn_insert) ;
  _conn_insert = null;
  _stmt_insert=null;
} // end method endInsert	 
	 
	 
/* Update the - argument record- from field variables */
public boolean updateRecord(int update_LogID)
	
throws java.sql.SQLException 
{
  boolean bUpdated = false ;
  java.sql.Connection conn = Connect();
	if(conn==null) return false ;
  try
	  {
    String query_update = psql.SQL(" UPDATE `debuglog` SET `LogTime` = ?, `Context` = ?, `LogText` = ?  WHERE `debuglog`.`LogID` = "+update_LogID+" ") ;
    java.sql.PreparedStatement stmt_update = conn.prepareStatement(query_update);
    // move data from bean variables to prepared statement
    storeData(stmt_update);
    if( stmt_update.executeUpdate()==1 ) bUpdated = true ;
    stmt_update.close();
    }
   finally
   {
      Disconnect(conn);
   }
   return bUpdated ;
} // end method updateRecord()

/* Delete the - argument record- from table */
public boolean deleteRecord(int delete_LogID)
throws java.sql.SQLException 
{
 boolean bDeleted = false ;
 java.sql.Connection conn = Connect() ;
 if(conn==null) return false ;
 try{
    String query_del = psql.SQL("  DELETE FROM `debuglog` WHERE `debuglog`.`LogID` = "+delete_LogID+" ") ;
    java.sql.Statement  stmt_del = conn.createStatement();
		if( stmt_del.executeUpdate(query_del) >0)bDeleted = true ; 
    stmt_del.close();
    }
  finally
    {
      Disconnect(conn);
    }
 return bDeleted ;
} // end method deleteRecord()

/* locate  the - argument record-  */
public boolean  locateRecord(int locate_LogID )
throws java.sql.SQLException
{
 boolean bLocated = false ;
 java.sql.Connection conn = Connect();
 if(conn==null) return false ;
 try{
    String query_locate = psql.SQL("  SELECT *  FROM `debuglog` WHERE `debuglog`.`LogID` = "+locate_LogID+" " ) ;
    java.sql.Statement  stmt_locate = conn.createStatement();
    java.sql.ResultSet rslt_locate = stmt_locate.executeQuery(query_locate); 
    if( rslt_locate.next())
      {
        bLocated = true ;
        loadData(rslt_locate);
      } 
    stmt_locate.close();
    }
   finally
    {
      Disconnect(conn);
    }
  return bLocated ;
} // end method locateRecord();

	/* Open and close methods for data access */
	private  java.sql.Connection _conn  ;
	private  java.sql.ResultSet _result ;
	private  java.sql.Statement _stmt ;
	private  String _query = null;

/* General purpose table opening method  */	
public ResultSet  openTable(String WhereClause, String OrderByClause )
 throws java.sql.SQLException
{
  _conn = Connect();
  _query =   psql.SQL("  SELECT * FROM `debuglog`  "+WhereClause+" "+OrderByClause) ;
  _stmt = _conn.createStatement();
  _result  = _stmt.executeQuery(_query); 
  return _result ;
  } // end method openTable();
	
public boolean nextRow()
throws java.sql.SQLException
{
  boolean retVal=false;
  if(_result==null)return false;
  retVal=_result.next();
  if(retVal==true)loadData(_result);
  return retVal;
}

public boolean skipRow()
throws java.sql.SQLException
{

  if(_result==null)return false;
  return _result.next();
} // end method skipRow()
	
public void closeTable()
throws java.sql.SQLException
{
  _stmt.close();
  Disconnect(_conn);
  _result=null;
} // end method closeTable()

/* General purpose arbitrary query executing method that updates table */	
public int executeUpdate( java.lang.String query )
  throws java.sql.SQLException
 {
 int ret_val = 0;
 java.sql.Connection conn = Connect();
 if(conn==null) return 0;
 try{
    java.sql.Statement stmt = conn.createStatement();
    ret_val = stmt.executeUpdate( psql.SQL(query) , Statement.RETURN_GENERATED_KEYS);
    stmt.close();
    }
 finally
    {
      Disconnect(conn);
    }
  return ret_val ;
 } // end method executeUpdate()
	
	private  java.sql.Connection _conn_qry  ;
	private  java.sql.ResultSet _result_qry ;
	private  java.sql.Statement _stmt_qry ;

/* General purpose arbitrary query executing method that retrives the data */	
public java.sql.ResultSet  openQuery(String query )
throws java.sql.SQLException
{
 _conn_qry = Connect();
 if(_conn_qry == null ) return null ;
 _stmt_qry = _conn_qry.createStatement();
 _result_qry  = _stmt_qry.executeQuery(psql.SQL(query)); 
 return _result_qry ;
} // end method openQuery()
	
public void closeQuery()
throws java.sql.SQLException
{
  _stmt_qry.close();
  Disconnect(_conn_qry);
  _result_qry=null;
} // end method closeQuery()
	

public int  recordCount(String WhereClause )
throws java.sql.SQLException
{
 int nCount=0;
 
 
 java.sql.Connection conn = Connect();
 if(conn==null) return 0;
 String query_count = psql.SQL("  SELECT COUNT(*) FROM `debuglog`  "+WhereClause );
    try
    {
    java.sql.Statement stmt_count = conn.createStatement();
    java.sql.ResultSet rslt_count = stmt_count.executeQuery(query_count); 
    if(rslt_count.next()) nCount=rslt_count.getInt(1);
    rslt_count.close();
    stmt_count.close();
    }
    finally
    {
      Disconnect(conn);
    }
 return nCount ;		
} // end method recordCount();

} /* End of class declaration for DebuglogBean */	


