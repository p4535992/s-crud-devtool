package com.$WEBAPP ;
import com.db.* ;

public class Logger
{
   private static com.db.$WEBAPP.DebuglogBean db = null ;
   public static void log(String cntx, String txt )
   {
     if ( db==null ) db = new com.db.$WEBAPP.DebuglogBean();
     try
     {
         db.LogID=0 ; 
	     db.LogTime = new java.sql.Timestamp(System.currentTimeMillis()) ; ; 
	     db.Context = cntx  ; 
	     db.LogText = txt ;
		 db.addRecord();
			 
     } catch(java.sql.SQLException ex) { }
   }
}