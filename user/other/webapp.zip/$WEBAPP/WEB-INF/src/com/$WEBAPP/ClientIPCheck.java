package com.$WEBAPP ;

import com.webapp.security.*;
import javax.servlet.http.* ;

public class ClientIPCheck implements com.webapp.security.ClientIPAccessControl
{

   private javax.servlet.ServletContext context = null ;
   public boolean permit(HttpServletRequest request, String role )
   {
         // return true to permit access false to redirect
         // parameter role should be used to make decision

	    return true ;
   }
   public String redirect(String role)
   {
         // return redirection string incase permit returns false
         // value to return is based on role parameter.
  
	    return null ;
   }
   public void init(javax.servlet.ServletContext cntx)
   {
	    this.context = cntx;
   }
}