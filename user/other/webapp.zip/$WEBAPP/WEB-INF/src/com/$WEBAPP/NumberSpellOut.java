package com.$WEBAPP ;
import java.lang.* ;
import java.util.* ;
import javax.servlet.*;
import javax.servlet.http.*;

public class NumberSpellOut
{

private static final String[] ones = 	{ "zero", "one", "two", "three", "four", "five", "six", "seven", 	  "eight", "nine" };
private static final String[] teens = { "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen",      "sixteen", "seventeen", "eighteen", "nineteen" };
private static final String[] tens =  { " ", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", 	  "eighty", "ninety" };
private static final String hundred = " hundred";
private static final String[] thousands = { " thousand", " lac", " crore", " billion", " trillion" };



public static String spellout(String number)
{
      int rupees = 0;
      int paise = 0 ;
      String[] parts = number.split("\\.");
      if(parts.length > 1) // Rupee and paise both
      {
           try
           {
               rupees=Integer.parseInt(parts[0]);
           }
           catch(NumberFormatException ex)
           {
               rupees=0;
           }
           try
           {
               paise=Integer.parseInt(parts[1]);
           }
           catch(NumberFormatException ex)
           {
               paise=0;
           }
      }  // Rupee alone
      else
      {
           try
           {
                rupees=Integer.parseInt(parts[0]);
           }
           catch(NumberFormatException ex)
           {
                rupees=0;
           }
      }  // end if
    return " Rupees  "+ spellint(rupees) + ( ( paise > 0  )? " and  paise "+spellint(paise)+" " : " " ) ;

}


public static String spellint(int x) 
{
	if (x < 10)
		return ones[x];
	if (x < 20)
		return teens[x - 10];
	if (x < 100) {
		if (x % 10 == 0)
			return tens[x / 10];
		else
			return tens[x / 10] + " " + ones[x % 10];
	}
	if (x < 1000) {
		if (x % 100 == 0)
			return ones[x / 100] + hundred;
		else
			return ones[x / 100] + hundred + " " +
						spellint(x % 100);
	}
//	if (x < 1000000) {
	if (x < 100000) {
		if (x % 1000 == 0)
			return spellint(x / 1000) + thousands[0];
		else
			return spellint(x / 1000) + thousands[0] + " " +
						spellint(x % 1000);
	}
	if (x < 10000000) {
		if (x % 100000 == 0)
			return spellint(x / 100000) + thousands[1];
		else
			return spellint(x / 100000) + thousands[1] + " " +spellint(x % 100000);
	}
	if (x < 1000000000) {
		if (x % 10000000 == 0)
			return spellint(x / 10000000) + thousands[2];
		else
			return spellint(x / 10000000) + thousands[2] + " " +spellint(x % 10000000);
	}
	
	
	return "";
}
}
 