package com.$WEBAPP ;

public class ApplicationResource
{
public static final String database = "jdbc/$WEBAPP"  ;
public static final String webapp   =  "$WEBAPP" ;
public static final String stylesheet =  "/style.css" ;
public static final String pagetitle =  "Web Application" ;
public static final String logo  =  "/images/logo.gif"  ;
public static final String banner  =  "/images/banner.gif" ; 
public static final String backlink_image =   "/images/back.gif" ; 
public static final String homelink_image =  "/images/home.gif" ; 
public static final String homepage = "/index.jsp" ;
public static final String homedir =  "/" ;
};
